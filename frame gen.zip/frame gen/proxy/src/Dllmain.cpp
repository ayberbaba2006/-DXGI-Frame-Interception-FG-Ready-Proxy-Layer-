#include <windows.h>
#include <cstdio>
#include "DxgiProxy.h"
#include "ProxyState.h"

using namespace FrameGenProxy;

BOOL WINAPI DllMain(HMODULE hModule, DWORD reason, LPVOID reserved) {
    switch (reason) {
        case DLL_PROCESS_ATTACH: {
#ifdef _DEBUG
            AllocConsole();
            FILE* fp = nullptr;
            freopen_s(&fp, "CONOUT$", "w", stdout);
            printf("[FrameGen Proxy] Debug console allocated\n");
#endif
            printf("[FrameGen Proxy] DLL_PROCESS_ATTACH\n");
            break;
        }
        case DLL_PROCESS_DETACH: {
            printf("[FrameGen Proxy] DLL_PROCESS_DETACH\n");
            ProxyState::Instance().Shutdown();
            DxgiProxy::Shutdown();
#ifdef _DEBUG
            FreeConsole();
#endif
            break;
        }
    }
    return TRUE;
}

extern "C" {
    HRESULT WINAPI CreateDXGIFactory(REFIID riid, void** ppFactory) {
        return DxgiProxy::CreateDXGIFactory(riid, ppFactory);
    }
    HRESULT WINAPI CreateDXGIFactory1(REFIID riid, void** ppFactory) {
        return DxgiProxy::CreateDXGIFactory1(riid, ppFactory);
    }
    HRESULT WINAPI CreateDXGIFactory2(UINT Flags, REFIID riid, void** ppFactory) {
        return DxgiProxy::CreateDXGIFactory2(Flags, riid, ppFactory);
    }
    HRESULT WINAPI DXGIGetDebugInterface(REFIID riid, void** ppDebug) {
        return DxgiProxy::DXGIGetDebugInterface(riid, ppDebug);
    }
    HRESULT WINAPI DXGIGetDebugInterface1(REFIID riid, void** ppDebug) {
        return DxgiProxy::DXGIGetDebugInterface1(riid, ppDebug);
    }
}