#include "DxgiProxy.h"
#include "ProxyState.h"
#include <cstdio>

using namespace FrameGenProxy;

std::atomic<bool> DxgiProxy::functionsLoaded_(false);
std::mutex DxgiProxy::loadMutex_;
decltype(&CreateDXGIFactory) DxgiProxy::real_CreateDXGIFactory = nullptr;
decltype(&CreateDXGIFactory1) DxgiProxy::real_CreateDXGIFactory1 = nullptr;
decltype(&CreateDXGIFactory2) DxgiProxy::real_CreateDXGIFactory2 = nullptr;
decltype(&DXGIGetDebugInterface) DxgiProxy::real_DXGIGetDebugInterface = nullptr;
decltype(&DXGIGetDebugInterface1) DxgiProxy::real_DXGIGetDebugInterface1 = nullptr;

bool DxgiProxy::EnsureFunctionsLoaded() {
    if (functionsLoaded_.load(std::memory_order_acquire)) return true;
    std::lock_guard<std::mutex> lock(loadMutex_);
    if (functionsLoaded_.load(std::memory_order_relaxed)) return true;
    HMODULE realDxgi = GetModuleHandleW(L"dxgi.dll");
    if (!realDxgi) return false;
    real_CreateDXGIFactory = (decltype(&CreateDXGIFactory))GetProcAddress(realDxgi, "CreateDXGIFactory");
    real_CreateDXGIFactory1 = (decltype(&CreateDXGIFactory1))GetProcAddress(realDxgi, "CreateDXGIFactory1");
    real_CreateDXGIFactory2 = (decltype(&CreateDXGIFactory2))GetProcAddress(realDxgi, "CreateDXGIFactory2");
    real_DXGIGetDebugInterface = (decltype(&DXGIGetDebugInterface))GetProcAddress(realDxgi, "DXGIGetDebugInterface");
    real_DXGIGetDebugInterface1 = (decltype(&DXGIGetDebugInterface1))GetProcAddress(realDxgi, "DXGIGetDebugInterface1");
    if (!real_CreateDXGIFactory || !real_CreateDXGIFactory1 || !real_CreateDXGIFactory2) return false;
    functionsLoaded_.store(true, std::memory_order_release);
    return true;
}

void DxgiProxy::Shutdown() {
    std::lock_guard<std::mutex> lock(loadMutex_);
    real_CreateDXGIFactory = nullptr;
    real_CreateDXGIFactory1 = nullptr;
    real_CreateDXGIFactory2 = nullptr;
    real_DXGIGetDebugInterface = nullptr;
    real_DXGIGetDebugInterface1 = nullptr;
    functionsLoaded_.store(false, std::memory_order_release);
}

HRESULT WINAPI DxgiProxy::CreateDXGIFactory(REFIID riid, void** ppFactory) {
    if (!ppFactory) return E_INVALIDARG;
    if (!EnsureFunctionsLoaded() || !real_CreateDXGIFactory) return DXGI_ERROR_NOT_FOUND;
    return real_CreateDXGIFactory(riid, ppFactory);
}

HRESULT WINAPI DxgiProxy::CreateDXGIFactory1(REFIID riid, void** ppFactory) {
    if (!ppFactory) return E_INVALIDARG;
    if (!EnsureFunctionsLoaded() || !real_CreateDXGIFactory1) return DXGI_ERROR_NOT_FOUND;
    return real_CreateDXGIFactory1(riid, ppFactory);
}

HRESULT WINAPI DxgiProxy::CreateDXGIFactory2(UINT Flags, REFIID riid, void** ppFactory) {
    if (!ppFactory) return E_INVALIDARG;
    if (!EnsureFunctionsLoaded() || !real_CreateDXGIFactory2) return DXGI_ERROR_NOT_FOUND;
    return real_CreateDXGIFactory2(Flags, riid, ppFactory);
}

HRESULT WINAPI DxgiProxy::DXGIGetDebugInterface(REFIID riid, void** ppDebug) {
    if (!ppDebug) return E_INVALIDARG;
    if (!EnsureFunctionsLoaded() || !real_DXGIGetDebugInterface) return E_NOTIMPL;
    return real_DXGIGetDebugInterface(riid, ppDebug);
}

HRESULT WINAPI DxgiProxy::DXGIGetDebugInterface1(REFIID riid, void** ppDebug) {
    if (!ppDebug) return E_INVALIDARG;
    if (!EnsureFunctionsLoaded() || !real_DXGIGetDebugInterface1) return E_NOTIMPL;
    return real_DXGIGetDebugInterface1(riid, ppDebug);
}

HRESULT STDMETHODCALLTYPE DxgiProxy::HookedPresent(IDXGISwapChain* pThis, UINT SyncInterval, UINT Flags) {
    if (!pThis) return E_INVALIDARG;
    ProxyState& state = ProxyState::Instance();
    state.FrameStart();
    return S_OK;
}

HRESULT STDMETHODCALLTYPE DxgiProxy::HookedPresent1(IDXGISwapChain1* pThis, UINT SyncInterval, UINT Flags, const DXGI_PRESENT_PARAMETERS* pPresentParameters) {
    if (!pThis) return E_INVALIDARG;
    ProxyState& state = ProxyState::Instance();
    state.FrameStart();
    return S_OK;
}

HRESULT STDMETHODCALLTYPE DxgiProxy::HookedResizeBuffers(IDXGISwapChain* pThis, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags) {
    if (!pThis) return E_INVALIDARG;
    ProxyState::Instance().OnSwapChainResize(Width, Height);
    return S_OK;
}