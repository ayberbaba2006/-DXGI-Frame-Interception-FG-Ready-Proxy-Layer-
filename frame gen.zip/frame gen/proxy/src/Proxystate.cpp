#include "ProxyState.h"
#include <cstdio>

using namespace FrameGenProxy;

ProxyState& ProxyState::Instance() {
    static ProxyState instance;
    return instance;
}

ProxyState::ProxyState() {}
ProxyState::~ProxyState() { Shutdown(); }

bool ProxyState::Initialize() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (initialized_) return true;
    if (!device_ || !queue_) return false;
    try {
        coreManager_ = std::make_unique<FrameGen::FrameManager>(device_, queue_);
    } catch (...) { return false; }
    if (!coreManager_->Initialize(1920, 1080)) {
        coreManager_.reset();
        return false;
    }
    initialized_ = true;
    return true;
}

void ProxyState::Shutdown() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (!initialized_) return;
    if (coreManager_) {
        coreManager_->Shutdown();
        coreManager_.reset();
    }
    device_ = nullptr;
    queue_ = nullptr;
    swapChain_ = nullptr;
    initialized_ = false;
}

bool ProxyState::IsInitialized() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return initialized_;
}

void ProxyState::SetDevice(ID3D12Device* device) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    device_ = device;
}

void ProxyState::SetCommandQueue(ID3D12CommandQueue* queue) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    queue_ = queue;
}

void ProxyState::SetSwapChain(IDXGISwapChain* swapChain) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    swapChain_ = swapChain;
}

ID3D12Device* ProxyState::GetDevice() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return device_;
}

ID3D12CommandQueue* ProxyState::GetQueue() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return queue_;
}

IDXGISwapChain* ProxyState::GetSwapChain() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return swapChain_;
}

void ProxyState::FrameStart() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (!initialized_) return;
    if (resizePending_) {
        if (coreManager_) {
            coreManager_->BeginSoftReset(currentWidth_, currentHeight_);
            coreManager_->EndSoftReset();
            resizePending_ = false;
        }
    }
}

void ProxyState::FrameEnd() {}

void ProxyState::OnSwapChainResize(uint32_t newWidth, uint32_t newHeight) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    currentWidth_ = newWidth;
    currentHeight_ = newHeight;
    resizePending_ = true;
}

bool ProxyState::IsCoreActive() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return initialized_ && coreManager_ && coreManager_->IsActive();
}

bool ProxyState::IsCoreValid() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return initialized_ && coreManager_ && coreManager_->IsInitialized();
}