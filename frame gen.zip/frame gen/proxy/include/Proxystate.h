#pragma once
#include <d3d12.h>
#include <dxgi1_6.h>
#include <mutex>
#include <memory>
#include "../core/include/FrameGen.h"

namespace FrameGenProxy {

class ProxyState {
public:
    static ProxyState& Instance();
    bool Initialize();
    void Shutdown();
    bool IsInitialized() const;
    void SetDevice(ID3D12Device* device);
    void SetCommandQueue(ID3D12CommandQueue* queue);
    void SetSwapChain(IDXGISwapChain* swapChain);
    ID3D12Device* GetDevice() const;
    ID3D12CommandQueue* GetQueue() const;
    IDXGISwapChain* GetSwapChain() const;
    void FrameStart();
    void FrameEnd();
    void OnSwapChainResize(uint32_t newWidth, uint32_t newHeight);
    FrameGen::FrameManager* GetCoreManager() { return coreManager_.get(); }
    bool IsCoreActive() const;
    bool IsCoreValid() const;

private:
    ProxyState();
    ~ProxyState();
    mutable std::mutex stateMutex_;
    std::unique_ptr<FrameGen::FrameManager> coreManager_;
    ID3D12Device* device_ = nullptr;
    ID3D12CommandQueue* queue_ = nullptr;
    IDXGISwapChain* swapChain_ = nullptr;
    uint32_t currentWidth_ = 0;
    uint32_t currentHeight_ = 0;
    bool initialized_ = false;
    bool resizePending_ = false;
};

}