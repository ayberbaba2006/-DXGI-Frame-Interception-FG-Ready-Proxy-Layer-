#pragma once
#include <dxgi1_6.h>
#include <d3d12.h>
#include <mutex>
#include <atomic>

namespace FrameGenProxy {

class DxgiProxy {
public:
    static void Shutdown();
    static HRESULT WINAPI CreateDXGIFactory(REFIID riid, void** ppFactory);
    static HRESULT WINAPI CreateDXGIFactory1(REFIID riid, void** ppFactory);
    static HRESULT WINAPI CreateDXGIFactory2(UINT Flags, REFIID riid, void** ppFactory);
    static HRESULT WINAPI DXGIGetDebugInterface(REFIID riid, void** ppDebug);
    static HRESULT WINAPI DXGIGetDebugInterface1(REFIID riid, void** ppDebug);
    static HRESULT STDMETHODCALLTYPE HookedPresent(IDXGISwapChain* pThis, UINT SyncInterval, UINT Flags);
    static HRESULT STDMETHODCALLTYPE HookedPresent1(IDXGISwapChain1* pThis, UINT SyncInterval, UINT Flags, const DXGI_PRESENT_PARAMETERS* pPresentParameters);
    static HRESULT STDMETHODCALLTYPE HookedResizeBuffers(IDXGISwapChain* pThis, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags);

private:
    static std::atomic<bool> functionsLoaded_;
    static std::mutex loadMutex_;
    static decltype(&CreateDXGIFactory) real_CreateDXGIFactory;
    static decltype(&CreateDXGIFactory1) real_CreateDXGIFactory1;
    static decltype(&CreateDXGIFactory2) real_CreateDXGIFactory2;
    static decltype(&DXGIGetDebugInterface) real_DXGIGetDebugInterface;
    static decltype(&DXGIGetDebugInterface1) real_DXGIGetDebugInterface1;
    static bool EnsureFunctionsLoaded();
};

}