#pragma once
#include <mutex>
#include <cstdint>

namespace FrameGen {

struct FrameSettings {
    float blendFactor = 0.5f;
    float motionScale = 1.0f;
    int quality = 50;
    bool enableSharpening = false;

    void Validate() {
        blendFactor = (blendFactor < 0.0f) ? 0.0f : (blendFactor > 1.0f) ? 1.0f : blendFactor;
        motionScale = (motionScale < 0.1f) ? 0.1f : (motionScale > 2.0f) ? 2.0f : motionScale;
        quality = (quality < 0) ? 0 : (quality > 100) ? 100 : quality;
    }

    void Reset() {
        blendFactor = 0.5f;
        motionScale = 1.0f;
        quality = 50;
        enableSharpening = false;
    }

    bool operator==(const FrameSettings& other) const {
        return blendFactor == other.blendFactor && motionScale == other.motionScale &&
               quality == other.quality && enableSharpening == other.enableSharpening;
    }
};

class SettingsManager {
public:
    SettingsManager();
    void SetSettings(const FrameSettings& s);
    FrameSettings GetSettings() const;
    FrameSettings GetSettingsCopy() const;
    bool IsDirty() const;
    void MarkClean();

private:
    mutable std::mutex settingsMutex;
    FrameSettings settings;
    bool dirty_ = false;
};

}