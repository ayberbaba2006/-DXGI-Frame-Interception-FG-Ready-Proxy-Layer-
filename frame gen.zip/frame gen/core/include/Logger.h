#pragma once
#include <cstdio>
#include <cstdarg>
#include <atomic>

namespace FrameGen::Debug {

class Logger {
public:
    enum class Level { Error, Warning, Info, Verbose };

#ifdef DEBUG
    static void Log(Level level, const char* format, ...) {
        if (level > Level::Verbose) return;
        static std::atomic<int> frameCounter(0);
        int frame = frameCounter_++;
        if (level == Level::Verbose && frame % 60 != 0) return;
        va_list args;
        va_start(args, format);
        const char* levelStr[] = { "ERROR", "WARN", "INFO", "VERBOSE" };
        printf("[FrameGen %s @ frame %d] ", levelStr[static_cast<int>(level)], frame);
        vprintf(format, args);
        printf("\n");
        va_end(args);
    }
    static void LogState(const char* msg) { Log(Level::Info, "State: %s", msg); }
#else
    static constexpr void Log(Level level, const char* format, ...) {}
    static constexpr void LogState(const char* msg) {}
#endif
};

}

#ifdef _DEBUG
#define FG_LOG(level, fmt, ...) FrameGen::Debug::Logger::Log(level, fmt, ##VA_ARGS)
#define FG_LOG_STATE(msg) FrameGen::Debug::Logger::LogState(msg)
#else
#define FG_LOG(level, fmt, ...)
#define FG_LOG_STATE(msg)
#endif