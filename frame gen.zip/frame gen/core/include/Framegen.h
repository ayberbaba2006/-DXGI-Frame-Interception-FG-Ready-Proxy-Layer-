#pragma once
#include <d3d12.h>
#include <wrl.h>
#include <memory>
#include <mutex>
#include "Core.h"
#include "Settings.h"

namespace FrameGen {

class FrameManager {
public:
    FrameManager(ID3D12Device* device, ID3D12CommandQueue* queue);
    ~FrameManager();

    bool Initialize(uint32_t width, uint32_t height);
    void Shutdown();
    bool SetActive(bool active);
    bool IsActive() const;
    void BeginSoftReset(uint32_t newWidth, uint32t newHeight);
    void EndSoftReset();
    void OnDeviceLost();
    bool Process(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* frame1, ID3D12Resource* frame2, ID3D12Resource* output);
    void SetSettings(const FrameSettings& settings);
    FrameSettings GetSettings() const;
    StateManager::State GetState() const;
    bool IsInitialized() const;
    bool IsError() const;
    bool IsProcessing() const;

private:
    bool CreateShaders();
    bool CreatePipeline();
    void ReleaseAllResources();
    bool BypassPipeline(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* input, ID3D12Resource* output);
    void OnError(const char* reason);
    bool ValidateInputs() const;

    ID3D12Device* device = nullptr;
    ID3D12CommandQueue* queue = nullptr;
    StateManager stateManager;
    SettingsManager settingsManager;
    Microsoft::WRL::ComPtr<ID3D12RootSignature> rootSig;
    Microsoft::WRL::ComPtr<ID3D12PipelineState> pso;
    Microsoft::WRL::ComPtr<ID3DBlob> csBlob;
    uint32t width = 0, height_ = 0;
    uint32t newWidth = 0, newHeight = 0;
    bool softResetPending = false;
    mutable std::mutex lifecycleMutex_;
};

}