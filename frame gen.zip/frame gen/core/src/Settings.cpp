#include "../include/Settings.h"

using namespace FrameGen;

SettingsManager::SettingsManager() : dirty_(false) {
    settings_.Validate();
}

void SettingsManager::SetSettings(const FrameSettings& s) {
    FrameSettings validated = s;
    validated.Validate();
    std::lock_guard<std::mutex> lock(settingsMutex_);
    if (settings_ == validated) return;
    settings_ = validated;
    dirty_ = true;
}

FrameSettings SettingsManager::GetSettings() const {
    return GetSettingsCopy();
}

FrameSettings SettingsManager::GetSettingsCopy() const {
    std::lock_guard<std::mutex> lock(settingsMutex_);
    return settings_;
}

bool SettingsManager::IsDirty() const {
    std::lock_guard<std::mutex> lock(settingsMutex_);
    return dirty_;
}

void SettingsManager::MarkClean() {
    std::lock_guard<std::mutex> lock(settingsMutex_);
    dirty_ = false;
}