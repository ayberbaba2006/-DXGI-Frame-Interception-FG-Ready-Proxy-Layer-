#include "../include/FrameGen.h"
#include "../include/Logger.h"
#include <d3dcompiler.h>
#include <cstring>

using namespace FrameGen;

FrameManager::FrameManager(ID3D12Device* device, ID3D12CommandQueue* queue)
    : device_(device), queue_(queue), softResetPending_(false) {}

FrameManager::~FrameManager() { Shutdown(); }

bool FrameManager::Initialize(uint32_t width, uint32_t height) {
    std::lock_guard<std::mutex> lock(lifecycleMutex_);
    if (stateManager_.IsInitialized()) return true;
    if (!device_ || width == 0 || height == 0) return false;
    width_ = width;
    height_ = height;
    if (!CreateShaders() || !CreatePipeline()) return false;
    stateManager_.SetInitialized();
    return true;
}

void FrameManager::Shutdown() {
    std::lock_guard<std::mutex> lock(lifecycleMutex_);
    if (!stateManager_.IsInitialized()) return;
    stateManager_.SetActive(false);
    ReleaseAllResources();
}

bool FrameManager::SetActive(bool active) {
    if (!stateManager_.IsInitialized()) return false;
    return stateManager_.SetActive(active);
}

bool FrameManager::IsActive() const { return stateManager_.IsActive(); }

void FrameManager::BeginSoftReset(uint32_t newWidth, uint32_t newHeight) {
    std::lock_guard<std::mutex> lock(lifecycleMutex_);
    if (newWidth == 0 || newHeight == 0) return;
    stateManager_.EnterSoftReset();
    newWidth_ = newWidth;
    newHeight_ = newHeight;
    softResetPending_ = true;
    ReleaseAllResources();
}

void FrameManager::EndSoftReset() {
    std::lock_guard<std::mutex> lock(lifecycleMutex_);
    if (!softResetPending_) return;
    width_ = newWidth_;
    height_ = newHeight_;
    if (!CreateShaders() || !CreatePipeline()) return;
    softResetPending_ = false;
    stateManager_.ExitSoftReset();
}

void FrameManager::OnDeviceLost() {
    stateManager_.SetDeviceLost();
    ReleaseAllResources();
}

bool FrameManager::Process(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* frame1,
                          ID3D12Resource* frame2, ID3D12Resource* output) {
    if (!ValidateInputs() || !cmdList || !frame1 || !frame2 || !output) return false;
    if (stateManager_.IsBypassEnabled()) {
        bool result = BypassPipeline(cmdList, frame1, output);
        stateManager_.AdvanceSoftResetFrame();
        return result;
    }
    cmdList->SetPipelineState(pso_.Get());
    cmdList->SetComputeRootSignature(rootSig_.Get());
    uint32_t groupsX = (width_ + 7) / 8;
    uint32_t groupsY = (height_ + 7) / 8;
    cmdList->Dispatch(groupsX, groupsY, 1);
    stateManager_.AdvanceSoftResetFrame();
    return true;
}

bool FrameManager::BypassPipeline(ID3D12GraphicsCommandList* cmdList, ID3D12Resource* input, ID3D12Resource* output) {
    if (!cmdList || !input || !output) return false;
    D3D12_RESOURCE_BARRIER barriers[2];
    barriers[0].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barriers[0].Transition.pResource = input;
    barriers[0].Transition.StateBefore = D3D12_RESOURCE_STATE_COMMON;
    barriers[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_SOURCE;
    barriers[0].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    barriers[1].Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    barriers[1].Transition.pResource = output;
    barriers[1].Transition.StateBefore = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    barriers[1].Transition.StateAfter = D3D12_RESOURCE_STATE_COPY_DEST;
    barriers[1].Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    cmdList->ResourceBarrier(2, barriers);
    cmdList->CopyResource(output, input);
    barriers[0].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_SOURCE;
    barriers[0].Transition.StateAfter = D3D12_RESOURCE_STATE_COMMON;
    barriers[1].Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
    barriers[1].Transition.StateAfter = D3D12_RESOURCE_STATE_UNORDERED_ACCESS;
    cmdList->ResourceBarrier(2, barriers);
    return true;
}

void FrameManager::SetSettings(const FrameSettings& settings) {
    settingsManager_.SetSettings(settings);
}

FrameSettings FrameManager::GetSettings() const {
    return settingsManager_.GetSettings();
}

StateManager::State FrameManager::GetState() const {
    return stateManager_.GetState();
}

bool FrameManager::IsInitialized() const {
    return stateManager_.IsInitialized();
}

bool FrameManager::IsError() const {
    return stateManager_.IsError();
}

bool FrameManager::IsProcessing() const {
    return stateManager_.CanProcess();
}

bool FrameManager::CreateShaders() {
    const char* hlslCode = R"(
        cbuffer Settings : register(b0) { float blendFactor; float motionScale; uint quality; uint padding; };
        Texture2D<float4> input1 : register(t0);
        Texture2D<float4> input2 : register(t1);
        RWTexture2D<float4> output : register(u0);
        [numthreads(8, 8, 1)]
        void main(uint3 id : SV_DispatchThreadID) {
            float4 pix1 = input1.Load(int3(id.xy, 0));
            float4 pix2 = input2.Load(int3(id.xy, 0));
            output[id.xy] = lerp(pix1, pix2, blendFactor);
        }
    )";
    Microsoft::WRL::ComPtr<ID3DBlob> errors;
    HRESULT hr = D3DCompile(hlslCode, strlen(hlslCode), nullptr, nullptr, nullptr, "main", "cs_5_0",
        D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &csBlob_, &errors);
    return SUCCEEDED(hr);
}

bool FrameManager::CreatePipeline() {
    if (!device_ || !csBlob_) return false;
    D3D12_DESCRIPTOR_RANGE srvRange{};
    srvRange.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
    srvRange.NumDescriptors = 2;
    D3D12_DESCRIPTOR_RANGE uavRange{};
    uavRange.RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_UAV;
    uavRange.NumDescriptors = 1;
    D3D12_ROOT_PARAMETER params[3]{};
    params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_CBV;
    params[0].Descriptor.ShaderRegister = 0;
    params[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    params[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    params[1].DescriptorTable.NumDescriptorRanges = 1;
    params[1].DescriptorTable.pDescriptorRanges = &srvRange;
    params[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    params[2].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
    params[2].DescriptorTable.NumDescriptorRanges = 1;
    params[2].DescriptorTable.pDescriptorRanges = &uavRange;
    params[2].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
    D3D12_ROOT_SIGNATURE_DESC rootSigDesc{};
    rootSigDesc.NumParameters = 3;
    rootSigDesc.pParameters = params;
    rootSigDesc.Flags = D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT;
    Microsoft::WRL::ComPtr<ID3DBlob> sig, error;
    HRESULT hr = D3D12SerializeRootSignature(&rootSigDesc, D3D_ROOT_SIGNATURE_VERSION_1, &sig, &error);
    if (FAILED(hr)) return false;
    hr = device_->CreateRootSignature(0, sig->GetBufferPointer(), sig->GetBufferSize(), IID_PPV_ARGS(&rootSig_));
    if (FAILED(hr)) return false;
    D3D12_COMPUTE_PIPELINE_STATE_DESC psoDesc{};
    psoDesc.pRootSignature = rootSig_.Get();
    psoDesc.CS = { csBlob_->GetBufferPointer(), csBlob_->GetBufferSize() };
    hr = device_->CreateComputePipelineState(&psoDesc, IID_PPV_ARGS(&pso_));
    return SUCCEEDED(hr);
}

void FrameManager::ReleaseAllResources() {
    pso_.Reset();
    rootSig_.Reset();
    csBlob_.Reset();
}

void FrameManager::OnError(const char* reason) {
    stateManager_.SetError(reason);
    ReleaseAllResources();
}

bool FrameManager::ValidateInputs() const {
    return stateManager_.IsInitialized() && !stateManager_.IsError() && device_ && queue_;
}

extern "C" {
FrameGen::FrameManager* FG_CreateManager(ID3D12Device* device, ID3D12CommandQueue* queue) {
    try { return new FrameGen::FrameManager(device, queue); } catch (...) { return nullptr; }
}
void FG_DestroyManager(FrameGen::FrameManager* manager) { if (manager) delete manager; }
bool FG_Initialize(FrameGen::FrameManager* manager, uint32_t width, uint32_t height) {
    return manager ? manager->Initialize(width, height) : false;
}
void FG_Shutdown(FrameGen::FrameManager* manager) { if (manager) manager->Shutdown(); }
bool FG_SetActive(FrameGen::FrameManager* manager, bool active) {
    return manager ? manager->SetActive(active) : false;
}
bool FG_IsActive(FrameGen::FrameManager* manager) {
    return manager ? manager->IsActive() : false;
}
bool FG_Process(FrameGen::FrameManager* manager, ID3D12GraphicsCommandList* cmdList,
                ID3D12Resource* frame1, ID3D12Resource* frame2, ID3D12Resource* output) {
    return manager ? manager->Process(cmdList, frame1, frame2, output) : false;
}
void FG_SetSettings(FrameGen::FrameManager* manager, float blendFactor, float motionScale, int quality, bool enableSharpening) {
    if (!manager) return;
    FrameGen::FrameSettings s;
    s.blendFactor = blendFactor;
    s.motionScale = motionScale;
    s.quality = quality;
    s.enableSharpening = enableSharpening;
    manager->SetSettings(s);
}
void FG_BeginSoftReset(FrameGen::FrameManager* manager, uint32_t newWidth, uint32_t newHeight) {
    if (manager) manager->BeginSoftReset(newWidth, newHeight);
}
void FG_EndSoftReset(FrameGen::FrameManager* manager) {
    if (manager) manager->EndSoftReset();
}
void FG_OnDeviceLost(FrameGen::FrameManager* manager) {
    if (manager) manager->OnDeviceLost();
}
int FG_GetState(FrameGen::FrameManager* manager) {
    return manager ? static_cast<int>(manager->GetState()) : -1;
}
}