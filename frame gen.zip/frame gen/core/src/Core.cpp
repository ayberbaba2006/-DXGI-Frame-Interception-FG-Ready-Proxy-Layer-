#include "../include/Core.h"
#include "../include/Logger.h"

using namespace FrameGen;
using namespace FrameGen::Debug;

StateManager::StateManager() : state_(State::Uninitialized), softResetFrameCounter_(0) {
    FG_LOG(Logger::Level::Info, "StateManager created");
}

bool StateManager::CanProcessUnsafe() const {
    return state_ == State::Active && softResetFrameCounter_ == 0;
}

bool StateManager::CanProcess() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return CanProcessUnsafe();
}

bool StateManager::IsBypassEnabled() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return state_ != State::Active || !CanProcessUnsafe();
}

bool StateManager::IsSoftResetSafetyFrame() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return softResetFrameCounter_ > 0;
}

void StateManager::AdvanceSoftResetFrame() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (softResetFrameCounter_ > 0) {
        softResetFrameCounter_--;
    }
}

bool StateManager::SetInitialized() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (state_ == State::Initialized) return true;
    state_ = State::Initialized;
    softResetFrameCounter_ = 0;
    return true;
}

bool StateManager::SetActive(bool active) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (!active) {
        if (state_ == State::Active) {
            state_ = State::Initialized;
            softResetFrameCounter_ = 0;
        }
        return true;
    }
    if (state_ != State::Initialized) return false;
    if (softResetFrameCounter_ > 0) return false;
    state_ = State::Active;
    return true;
}

bool StateManager::SetError(const char* reason) {
    std::lock_guard<std::mutex> lock(stateMutex_);
    state_ = State::Error;
    softResetFrameCounter_ = 0;
    return true;
}

bool StateManager::SetDeviceLost() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    state_ = State::DeviceLost;
    softResetFrameCounter_ = 0;
    return true;
}

void StateManager::EnterSoftReset() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (state_ == State::Active) {
        state_ = State::SoftReset;
        softResetFrameCounter_ = SOFT_RESET_SAFETY_FRAMES;
    }
}

void StateManager::ExitSoftReset() {
    std::lock_guard<std::mutex> lock(stateMutex_);
    if (state_ == State::SoftReset) {
        state_ = State::Initialized;
        softResetFrameCounter_ = 0;
    }
}

StateManager::State StateManager::GetState() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return state_;
}

bool StateManager::IsInitialized() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return state_ != State::Uninitialized && state_ != State::Error && state_ != State::DeviceLost;
}

bool StateManager::IsError() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return state_ == State::Error || state_ == State::DeviceLost;
}

bool StateManager::IsActive() const {
    std::lock_guard<std::mutex> lock(stateMutex_);
    return state_ == State::Active;
}

void StateManager::LogStateChange(State oldState, State newState) const {
}